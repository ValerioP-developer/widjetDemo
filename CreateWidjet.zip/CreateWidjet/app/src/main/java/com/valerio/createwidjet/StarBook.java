package com.valerio.createwidjet;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "book")
public class StarBook {

    @PrimaryKey(autoGenerate = true)
    private int id_key;

    public String getId_book() {
        return id_book;
    }
    @ColumnInfo(name = "id_book")
    private String id_book;
    @ColumnInfo(name = "title_book")
    private String titleBook;
    @ColumnInfo(name = "description_book")
    private String descriptionBook;
    @ColumnInfo(name = "link_picture_book")
    private String linkPicture;
    @ColumnInfo(name = "link_audio_book")
    private String linkAudio;
    @ColumnInfo(name = "author_book")
    private String author;


    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }


    public StarBook( String id_book, String titleBook, String descriptionBook , String  linkPicture , String linkAudio ,String author){
        this.id_book = id_book;
        this.titleBook = titleBook ;
        this.descriptionBook = descriptionBook ;
        this.linkPicture = linkPicture ;
        this.linkAudio = linkAudio ;
        this.author = author ;
    }

    public int getId_key() {
        return id_key;
    }

    public void setId_key(int id_key) {
        this.id_key = id_key;
    }


    public String getTitleBook() {
        return titleBook;
    }

    public void setTitleBook(String titleBook) {
        this.titleBook = titleBook;
    }

    public String getDescriptionBook() {
        return descriptionBook;
    }

    public void setDescriptionBook(String descriptionBook) {
        this.descriptionBook = descriptionBook;
    }

    public String getLinkPicture() {
        return linkPicture;
    }

    public void setLinkPicture(String linkPicture) {
        this.linkPicture = linkPicture;
    }

    public String getLinkAudio() {
        return linkAudio;
    }

    public void setLinkAudio(String linkAudio) {
        this.linkAudio = linkAudio;
    }


}