package com.valerio.createwidjet;

import android.content.Context;
import android.util.Log;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;


@Database(entities = {StarBook.class }, version = 1 ,exportSchema = false)

public abstract class CreateDatabase extends RoomDatabase  {

   private static final String LOG_TAG = CreateDatabase.class.getSimpleName();
   private static final Object  LOCK = new Object();
   private static final String DATABASE_NAME = "favorites_1";
   private static  CreateDatabase sIstance ;

       public static CreateDatabase getsIstance(Context context){
             if(sIstance == null) synchronized (LOCK) {
               //  Log.d(LOG_TAG, "Creating new database istance");
                 sIstance = Room.databaseBuilder(context.getApplicationContext(),
                            CreateDatabase.class, CreateDatabase.DATABASE_NAME).
        //REMEMBER DO NOT USE IT       //   allowMainThreadQueries().
                         build();
             }


             Log.d(LOG_TAG , "Getting database istance "+sIstance);

             return sIstance ;
       }


       public abstract DaoStarBook BookDAO();

       public static CreateDatabase getUniqueInstance(){
           return sIstance;
       }



   }





