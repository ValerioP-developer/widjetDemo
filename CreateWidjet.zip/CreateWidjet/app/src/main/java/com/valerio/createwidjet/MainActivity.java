package com.valerio.createwidjet;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private CreateDatabase myDb ;
    private Button btn ;
    private String authors[]={"Dante Alighieri","Stephen King","Alessandro Manzoni","Diego Fusaro", "Omero"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.add_btn);
        myDb =CreateDatabase.getsIstance(this);
       // manageThread();
        addBook();
    }



    public void manageThread(){
        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {
                StarBook s = new StarBook("test", "title", "descr" , "link" , "aduio" , "author");
                StarBook s2 = new StarBook("test2", "title2", "descr2" , "link2" , "aduio2" , "author2");
                StarBook s3 = new StarBook("test3", "title3", "descr3" , "link3" , "aduio3" , "author3");
                myDb.BookDAO().insertBook(s);
                myDb.BookDAO(). insertBook(s2);
                myDb.BookDAO().insertBook(s3);
            }
        });
    }


    public void getBook(){

        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {
                List<StarBook> bookList = myDb.BookDAO().loadBookWithId(  "test");
                int size= bookList.size();
                Log.d("size LL" , bookList.get(0).getAuthor());
            }
        });

    }


    public void addBook(){
        btn = findViewById(R.id.add_btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AppExecutors.getInstance().diskIO().execute(new Runnable() {
                    @Override
                    public void run() {
                        //Fake book with casual author
                        StarBook s = new StarBook("test3", "title3", "descr3" , "link3" , "aduio3" , authors[generateCasualAuthorIndex(0,authors.length-1)]+", "  );
                        myDb.BookDAO().insertBook( s );

                        Intent intent = new Intent(MainActivity.this, NewAppWidget.class);
                        intent.setAction("android.appwidget.action.APPWIDGET_UPDATE");
                        int ids[] = AppWidgetManager.getInstance(getApplication()).getAppWidgetIds(new ComponentName(getApplication(), NewAppWidget.class));

                        intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS,ids);
                        sendBroadcast(intent);
                    }
                });
            }

        });


    }

    //It generates a casual index. It will be used to get a casual author from the array authors
    public static int generateCasualAuthorIndex(int min, int max){
        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }

        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }


}
