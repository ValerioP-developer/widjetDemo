package com.valerio.createwidjet;

import android.database.Cursor;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

@Dao
public interface DaoStarBook {

    @Query("select id_book  from book")
    List<String> getAllIdBookFromFavourite();

    @Insert
    void insertBook(StarBook starBook);

    @Update(onConflict = OnConflictStrategy.REPLACE)
    void updateBook(StarBook starBook);

    @Delete
    void deleteBook(StarBook starBook);

    @Query("select *  from book ")
    List<StarBook>  loadFavouriteBooks();

    @Query("delete from book where id_book =:idbook")
    void deleteBookById(String idbook);

    @Query("select *  from book where id_book =:idbook")
    List<StarBook>  loadBookWithId(String idbook);

    @Query("select *  from book")
    Cursor loadWidjetFavouriteBooks();


}
