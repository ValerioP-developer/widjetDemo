package com.valerio.createwidjet;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.RemoteViews;

import java.util.List;

/**
 * Implementation of App Widget functionality.
 */
public class NewAppWidget extends AppWidgetProvider {

    static void updateAppWidget(final Context context, final AppWidgetManager appWidgetManager,
                                final int appWidgetId) {

       // final CharSequence widgetText = context.getString(R.string.appwidget_text);
        // Construct the RemoteViews object

        new AsyncTask<Context, Void, List<StarBook>>(){

            @Override
            protected List<StarBook> doInBackground(Context... context) {

                List<StarBook> List=null;
                CreateDatabase db = CreateDatabase.getsIstance( context[0]);
                List = db.BookDAO().loadFavouriteBooks();

                return List;
            }

            @Override
            protected void onPostExecute(List<StarBook> List) {

                if(List != null){
                    RemoteViews views = new RemoteViews(  context.getPackageName() , R.layout.new_app_widget  );
                    views.setTextViewText(R.id.appwidget_text, createListText(List));

                    appWidgetManager.updateAppWidget(appWidgetId, views);
                }
            }


           public String createListText(  List<StarBook> List){
                String listAuthor=null;
StringBuilder s=new StringBuilder();
                if(List!=null && List.size()>0)

                    for(int i =0 ; i< List.size() ; i++){
                      s.append(  List.get(i).getAuthor());
                   }

            //   Log.d("author2121 ",listAuthor);
                return  s.toString();
           }



        }.execute(new Context[] {context});

           /*
            RemoteViews views = new RemoteViews(  context.getPackageName() , R.layout.new_app_widget  );
            views.setTextViewText(R.id.appwidget_text, widgetText);

            // Instruct the widget manager to update the widget
            appWidgetManager.updateAppWidget(appWidgetId, views);
            */
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        // There may be multiple widgets active, so update all of them
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId);
        }
    }

    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created
    }

    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }

    public NewAppWidget getC(){
        return this;
    }





}

